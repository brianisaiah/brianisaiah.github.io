# Brian Isaiah Personal Website

Open `index.html` in a browser to preview the website.

To publish it, you can upload the folder to a static hosting service such as GitHub Pages, Netlify, or another web host. A custom domain can then be connected.
